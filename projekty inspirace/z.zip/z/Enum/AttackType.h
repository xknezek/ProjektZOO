//
// Created by lucka on 12/29/2022.
//

#ifndef COMBAT_CPP_ATTACKTYPE_H
#define COMBAT_CPP_ATTACKTYPE_H
enum class AttackType{
    Heavy,
    Light
};
#endif //COMBAT_CPP_ATTACKTYPE_H
