//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_COMBAT_H
#define PROJECTX_COMBAT_H



#include <iostream>
#include <ctime>
#include <cstdlib>

#include "Attack.h"
#include "Light.h"
#include "Heavy.h"
#include "../Enum/AttackType.h"
#include "../Entities/Enemy.h"
#include "../Entities/Player.h"
/**
 * Combat class for attacking, fighting or fleeing.
 */

class Combat {
private:
   const float m_lightAtt = 0.8;
  const float m_heavyAtt = 1.4;

    Player* m_player;
    Enemy* m_enemy;
    Light* light;
    Heavy* heavy;
    bool m_playerTurn;
public:
/**
 * Constructor for combat.
 * @param player Addresses the player from memory.
 * @param enemy Addresses the enemy from memory.
 * @param playerTurn Value is true if it's the player's turn. False if it isn't.
 */
Combat(Player*player,Enemy*enemy, bool playerTurn);

    /**
     * Void function for combat.
     * @param attType Value based on selected type of attack.
     * @param playerTurn Value is true if it's the player's turn. False if it isn't.
     */
    void round(AttackType attType, bool playerTurn);

    /**
    *Bool function for fleeing.
    */
    bool flee();
};



#endif //PROJECTX_COMBAT_H
