//
// Created by filip on 04.11.2022.
// Edited by Michal Kadlec on 09.11.2022 patch 0.2.2
//

#include "Entity.h"

Entity::Entity(int agility, int defence,int health, int strength, int maxHealth, std::array<int, 2> position) {
    m_agility =  agility;
    m_maxHealth = maxHealth;
    m_health = health;
    m_defence = defence;
    m_position = position;
    m_strength = strength;

}
//metoda pro nastaveni hodnoty
int Entity::getAgility(){
    return m_agility;
}
//metoda pro ziskani hodnoty obrany
int Entity::getDefence() {
    return m_defence;
}
//metoda pro ziskani hodnoty sily
int Entity::getStrength() {
    return m_strength;
}
//metoda pro ziskani hodnoty maximalnich zivotu
int Entity::getMaxHealth() {
    return  m_maxHealth;
}

//metoda pro ziskani hodnoty zivotu
int Entity::getHealth() {
    return m_health;
}

//metoda pro nastaveni zivotu pro metodu combat,enemy a Player nelze dostat negativni cislo
void Entity::setHealth(int health) {
    if(health<0){
        m_health = 0;
    }
    else if(health>getTotalMaxHealth()){
        m_health = getTotalMaxHealth();
    }
    else{
        m_health = health;
    }

}

std::array<int,2> Entity::getPosition() {
    return m_position;
}
void Entity::setPosition(std::array<int,2>position) {
    m_position = position;
}

int Entity::getTotalAgility(){
    std::vector<Item*> inv = m_inventory->getInventory();
    int totalStat=getAgility();
    for (Item* item:inv) {
        if (item && item->isEquipped()){
            totalStat+=item->getAgility();
        }
    }
    return totalStat;
}

int Entity::getTotalDefence(){
    std::vector<Item*> inv = m_inventory->getInventory();
    int totalStat=getDefence();
    for (Item* item:inv) {
        if (item && item->isEquipped()){
            totalStat+=item->getDefence();
        }
    }
    return totalStat;
}

int Entity::getTotalStrength(){
    std::vector<Item*> inv = m_inventory->getInventory();
    int totalStat=getStrength();
    for (Item* item:inv) {
        if (item && item->isEquipped()){
            totalStat+=item->getStrength();
        }
    }
    return totalStat;
}

int Entity::getTotalMaxHealth(){
    std::vector<Item*> inv = m_inventory->getInventory();
    int totalStat=getMaxHealth();
    for (Item* item:inv) {
        if (item && item->isEquipped()){
            totalStat+=item->getHealth();
        }
    }
    return totalStat;
}

std::vector<Item*> Entity::getInventory(){
    return m_inventory->getInventory();
}

bool Entity::addItem(Item* item){
    return m_inventory->addItem(item);
}