//
// Created by filip on 04.11.2022.
//

#ifndef PROJECTX_PLAYER_H
#define PROJECTX_PLAYER_H


#include <vector>
#include <array>
#include "Entity.h"
#include <string>

/**
 * Player class for stats and crafting.
 */
class Player: public Entity{
private:
    int m_revives;
    float m_luck;
    int m_skillPoint;
    int m_xp;
    int m_xpMax;
    int m_level;

/**
 * Void method to increase player's level.
 */
    void levelUp();
public:
    /**
     * Constructor for player.
     * @param agility
     * @param defence
     * @param health
     * @param strength
     * @param maxHealth
     * @param position
     * @param luck
     * @param xpMax
     * @param xp
     * @param level
     * @param skillPoint
     * @param revives
     */
    Player(int agility,
           int defence,
           int health,
           int strength,
           int maxHealth,
           std::array<int, 2> position,
           float luck,
           int xpMax,
           int xp,
           int level,
           int skillPoint,int revives
           );

    /**
     *Int function for getting player's experience value.
     * @return Returns player's experience value.
     */
    int getXp();

    /**
     *Int function to set the value of experience points.
     * @param XpIncrease Value based on amount of experience points dropped from an enemy after a fight.
     */
    void setXp(int XpIncrease);

    /**
     *Void function for choosing which skill to increase.
     * @param choice Value based on player's choice.
     */
    void skillPointAdd(int choice);

    /**
     *Int function to get player's level.
     * @return Returns player's level.
     */
    int getLevel();

    /**
     *Int function to get value of experience points required for next level.
     * @return Returns the value of experience points required for next level.
     */
    int getMaxXP();

    /**
     *Float function to get player's luck level.
     * @return Returns player's luck.
     */
    float getLuck();

    /**
     * Void function to change the amount of revives.
     * @param revivesChange Increases or decreases the amount of revives.
     */
    void changeRevives(std::string revivesChange);

    /**
     * Int function to get the amount of player's revives.
     * @return Returns the amount of player's revives.
     */
    int getRevives();

    /**
     * Int function to get the amount of player's skill points.
     * @return Returns the amount of player's skill points.
     */
    int getSkillPoint();

    /**
     * Void function to equip items.
     * @param item Selected item.
     */
    void equipItem(Item* item);

    /**
     * Void function to set the amount of revives.
     * @param revives Value based on the amount of revives.
     */
    void setRevives(int revives);

    /**
     * Function to drop item from inventory.
     * @param item Value based on selected item.
     * @return Returns selected item to drop.
     */
    Item* dropItem(Item* item);
};


#endif //PROJECTX_PLAYER_H
