/*



            ******Created by filip on 04.11.2022.*******
            ******Edited by Michal on 22.11.2022.*******  ******Patch 0.3.9*******



*/
/*

            ****Balancni cast PLayera*******
*/
//TODO odladit Velikost hodnot pro Staty
 int m_healthIncrease = 10;
 int m_agilityIncrease = 2;
 int m_defenceIncrease = 2;
 float m_luckIncrease = 0.15;
 int m_strengthIncrease = 2;

/*

            ****Logicka cast Playera*******
*/

#include "Player.h"

Player::Player(int agility, int defence, int health,
               int strength, int maxHealth,
               std::array<int, 2> position,
               float luck, int xpMax,
               int xp, int level,
               int skillPoint, int revives) :
        Entity(agility, defence, health, strength, maxHealth, position) {

    m_luck = luck;
    m_xp = xp;
    m_xpMax = xpMax;
    m_level = level;
    m_skillPoint = skillPoint;
    m_revives = revives;
}

//metoda pro prirazeni xp po zabiti enemy z metody combat
void Player::setXp(int XpIncrease) {
    m_xp += XpIncrease;
    while(m_xp>=m_xpMax) {
        if (m_xp >= m_xpMax) {
            m_xp += XpIncrease;
            m_xp -= m_xpMax;
            m_xpMax = (int) (m_xpMax * 1.25);
            m_skillPoint++;
            levelUp();

        }
    }

}

//metoda pro vraceni xp  (predano do m_inventory menu)
int Player::getXp() {
    return m_xp;
}

//metoda pro vraceni hranice xp pro dalsi lvl (predano do inventrory menu)
int Player::getMaxXP() {
    return m_xpMax;
}

int Player::getSkillPoint() {
    return m_skillPoint;
}

//metoda pro pridani skill pointu pro hrace (pristup z m_inventory menu)
void Player::skillPointAdd(int choice) {
    //Logika pro pridani statu pro hrace

    if (m_skillPoint > 0) {
        switch (choice) {
            case 0:
                //kdyz hrac vybere 0 pri vyberu priradi se skill point pro zivoty
                m_maxHealth += m_healthIncrease;
                m_health += m_healthIncrease;
                break;
            case 1:
                //kdyz hrac vybere 1 pri vyberu priradi se skill point pro silu
                m_strength += m_strengthIncrease;
                m_inventory->lvlUp();
                break;
            case 2:
                //kdyz hrac vybere 2 pri vyberu priradi se skill point pro obranu
                m_defence += m_defenceIncrease;
                break;
            case 3:
                //kdyz hrac vybere 3 pri vyberu priradi se skill point pro hbytost
                m_agility += m_agilityIncrease;
                break;
            case 4:
                //kdyz hrac vybere 4 pri vyberu priradi se skill point pro stesti
                if(m_luck < 0.9){
                    if(int(m_luck*100)%5==0 && int(m_luck*100)/5!=1){
                        m_luckIncrease= std::max(0.01,m_luckIncrease*0.2);
                    }
                }
                m_luck += m_luckIncrease;
                break;
            case 5:
                //kdyz hrac vybere 5 pri vyberu, priradi skill point pro revive (priradi jeden revive)
                m_revives++;
                break;
            default:
                //kdyz hrac nevybere tak se mu skill point ponecha odkaz na radek c. 74
                m_skillPoint++;
                break;
        }
        m_skillPoint--;
    }
}

//Zvysi level pro hrace
void Player::levelUp() {
    m_level++;
}

//vraci hodnotu levelu
int Player::getLevel() {
    return m_level;
}

//metoda pro ziskani stesti
float Player::getLuck() {
    return m_luck;
}

int Player::getRevives() {
    return Player::m_revives;
}

void Player::changeRevives(std::string revivesChange) {
    if (revivesChange == "increase") {
        Player::m_revives++;
    } else if (revivesChange == "decrease" && m_revives-- < 0) {
        m_revives = 0;
    } else {
        m_revives--;
    }
}

void Player::equipItem(Item *item) {
    if (item->getType() == ItemType::Potion) {
        setHealth(getHealth() + item->getHealth());
        delete dropItem(item);
        return;
    }
    m_inventory->equipItem(item);
}

Item *Player::dropItem(Item *item) {
    if (!item)return nullptr;
    item->setPos(m_position);
    return m_inventory->dropItem(item);
}
void Player::setRevives(int revives){
    m_revives=revives;
}

