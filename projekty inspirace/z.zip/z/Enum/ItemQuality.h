//
// Created by filip on 25.12.2022.
//

#ifndef PROJECTX_ITEMQUALITY_H
#define PROJECTX_ITEMQUALITY_H

enum class ItemQuality{
    Common,
    Uncommon,
    Rare,
    Epic,
    Legendary
};

#endif //PROJECTX_ITEMQUALITY_H
