//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_ENEMYMOVEMENT_H
#define PROJECTX_ENEMYMOVEMENT_H


class EnemyMovement {

};


#endif //PROJECTX_ENEMYMOVEMENT_H
