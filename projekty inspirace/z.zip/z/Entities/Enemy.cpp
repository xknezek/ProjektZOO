//
// Created by lucka on 11/4/2022.
//

#include "Enemy.h"

Enemy::Enemy(int agility, int defence, int health, int strength, int maxHealth, std::array<int, 2> Position): Entity(agility, defence, health, strength, maxHealth, Position) {
    m_id = m_count;
    m_count++;
}


void Enemy::dropInventory(){
    std::vector<Item*> inv = m_inventory->getInventory();
    for (Item* item:inv) {
        m_inventory->dropItem(item);
    }
}