//
// Created by czem1 on 07.12.2022.
//

#ifndef PROJECTX_HEAVY_H
#define PROJECTX_HEAVY_H
#include "time.h"
#include "Attack.h"
/**
 * Class for heavy attack.
 */
class Heavy: public Attack {
public:
        /**
         * Constructor for heavy attack.
         * @param player Player's stats.
         * @param enemy Enemy's stats.
         */
        Heavy(Player* player, Enemy* enemy);

        /**
         * Void function for calculating the damage given by player.
         */
        void calcPlayerDmg();

        /**
         * Void function for calculating the damage received from an enemy.
         */
        void calcEnemyDmg();
};


#endif //PROJECTX_HEAVY_H
