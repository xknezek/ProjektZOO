//
// Created by czem1 on 06.12.2022.
//

#include "Inventory.h"

Inventory::Inventory() {
    for (int i = 0; i < baseInventorySize; i++) {
        m_inventory.push_back(nullptr);
    }
    m_inventory.at(0) = new Item(ItemType::Gold, ItemQuality::Legendary, 0, 0, 0, 10, {});
}

bool Inventory::addItem(Item *item) {
    bool added = false;
    for (int i = 0; i < m_inventory.size(); i++) {
        if(!m_inventory.at(i)){
            m_inventory.at(i)=item;
            added=true;
            break;
        }
    }
    return added;
}

//Vezme item z inventáře a vrátí ho k dropnutí na zem
Item *Inventory::dropItem(Item *item) {
    for (int i = 0; i < m_inventory.size(); i++) {
        if(!item || !m_inventory.at(i)){ continue;}
        if (item->getId() == m_inventory.at(i)->getId()) {
            m_inventory.at(i) = nullptr;
            return item;
        }
    }
    return nullptr;
}

std::vector<Item *> Inventory::getInventory() {
    return m_inventory;
}

void Inventory::lvlUp() {
    m_inventory.push_back(nullptr);
}

void Inventory::equipItem(Item *item) {//TODO potion usage
    for (int i = 0; i < m_inventory.size(); i++) {
        if (m_inventory.at(i)) {
            if (item->getType() == m_inventory.at(i)->getType()) {
                m_inventory.at(i)->setEquip(false);
                item->setEquip(true);
            }
        }
    }
}

