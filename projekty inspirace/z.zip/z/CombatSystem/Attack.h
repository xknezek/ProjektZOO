//
// Created by czem1 on 07.12.2022.
//

#ifndef PROJECTX_ATTACK_H
#define PROJECTX_ATTACK_H

#include "../Entities/Enemy.h"
#include "../Entities/Player.h"

/**
 * Class for attack.
 */
class Attack {
protected:
    Player *m_player;
    Enemy *m_enemy;
    float m_attackAffinity;
    float m_damageAffinity;
public:

    /**
     * Constructor for attack.
     * @param player
     * @param enemy
     * @param damageAffinity
     * @param attackAffinity
     */
    Attack(Player* player, Enemy* enemy, float damageAffinity, float attackAffinity);

    /**
     * Void function for calculating the damage received by enemy.
     */
    virtual void calcEnemyDmg() = 0;

    /**
     * Void function for calculation the damage given by player
     */
    virtual void calcPlayerDmg() = 0;

};


#endif //PROJECTX_ATTACK_H
