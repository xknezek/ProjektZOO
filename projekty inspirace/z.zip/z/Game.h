//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_GAME_H
#define PROJECTX_GAME_H

#include <iostream>
#include "Inventory/Item.h"
#include "Entities/Enemy.h"
#include "Entities/Player.h"
#include "Map/Room.h"
#include "Map/Map.h"
#include <windows.h>
#include "Controls.h"
#include <ctime>
#include <cstdio>
#include <thread>
#include <mutex>
#include "Enum/Colors.h"
#include <fstream>
#include "CombatSystem/Combat.h"
#include "Crafting/Patron.h"

/**
 * Class for game logic.
 */
class Game {
private:
    Patron* m_patron;
    clock_t start;
    Room* m_room;
    Map* m_map;
    Combat* m_combat;
    std::string buffer;
    std::mutex m;
    std::thread keyHit;
    bool m_exit, isPlayerTurn, isLarge;
    HANDLE console_output;
    bool m_playerTurn;
    int m_roomsCount;

    /**
     * Char function for movement without using enter.
     * @return Returns pressed button and EOF.
     */
    char GetCh();

    /**
     * Bool function to get player's input.
     * @param input Value based on player's input.
     * @return Returns if the game ended.
     */
    bool keyEvent(char input);

    /**
     * Void function to spend skill points on stats.
     */
    void spendSkillPoint();

    /**
     * Void function to print info about the game.
     */
    void about();

    /**
     * Void function to print room.
     */
    void printRoom();

    /**
     * Void function to print minimap
     */
    void printMinimap();

    /**
     * Void function to start a new game.
     */
    void newGame();

    /**
     * Void function for printing inventory.
     */
    void printInventory();

    /**
     * Void function to start the game.
     */
    void play();

    /**
     * Bool function for printing combat interface.
     * @param enemy Gets stats of an enemy from vector of enemies.
     * @return Returns if player died.
     */
    bool combatInterface(Enemy* enemy);

    /**
     * Bool function to end the game and return the player to menu.
     * @param win True if player won. False if he lost.
     * @return Returns if the game should end.
     */
    bool endGame(bool win);
public:
    /**
     * Constructor for game.
     */
    Game();

    /**
     * Void function to print menu.
     */
    void menu();

    /**
     * Destructor for game.
     */
    ~Game();
};


#endif //PROJECTX_GAME_H
