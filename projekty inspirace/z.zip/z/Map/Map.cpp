//
// Created by lucka on 11/4/2022.
//

#include "Map.h"

const int baseAgility = 5;
const int baseDefence = 5;
const int baseHealth = 50;
const int baseStrength = 5;
const int baseMaxHealth = baseHealth;
const float baseLuck = 0.05;
const int baseXpMax = 10;
const int baseXp = 0;
const int baseLevel = 1;
const int baseSkillPoint = 1;
const int baseRevives = 1;

Map::Map(int roomsNumber){
    m_roomsNumber = roomsNumber;
    m_completedRooms = 1;
    int arrayLen = sqrt(m_roomsNumber * 4);
    for (int i = 0; i < arrayLen; i++) {
        std::vector<Room*> roomRow;
        for (int j = 0; j < arrayLen; j++) {
            roomRow.push_back(nullptr);
        }
        m_rooms.push_back(roomRow);
    }
    mapGen();
}

void Map::mapGen(){
    m_firstRoom = firstRoom();
    generateRoom(m_firstRoom);
    connectRooms();
    shortenMap();
}

Room* Map::getMap(){
    return m_firstRoom;
}

void Map::nextRoom(std::array<int, 2> start, int& limitRooms){
    m_rooms.at(start[0]).at(start[1]) = newRoom();
    limitRooms--;
    if (limitRooms <= 0){
        return;
    }
    std::array<int, 2> pretendPos;
    while (checkEmptyAdjacentTiles(start)) {
        int randomRoom = rand() % 4;
        switch (randomRoom) {
            case 0:
                if (!checkPos({start[0] + 1, start[1] + 0}) || m_rooms.at(start[0] + 1).at(start[1] + 0)) {
                    continue;
                }
                pretendPos = {start[0] + 1, start[1] + 0};
                break;
            case 1:
                if (!checkPos({start[0] - 1, start[1] + 0}) || m_rooms.at(start[0] - 1).at(start[1] + 0)) {
                    continue;
                }
                pretendPos = {start[0] - 1, start[1] + 0};
                break;
            case 2:
                if (!checkPos({start[0] + 0, start[1] + 1}) || m_rooms.at(start[0] + 0).at(start[1] + 1)) {
                    continue;
                }
                pretendPos = {start[0] + 0, start[1] + 1};
                break;
            case 3:
                if (!checkPos({start[0] + 0, start[1] - 1}) || m_rooms.at(start[0] + 0).at(start[1] - 1)) {
                    continue;
                }
                pretendPos = {start[0] + 0, start[1] - 1};
                break;
        }
        break;
    }
    if (!checkEmptyAdjacentTiles(start)){
        return;
    }
    nextRoom(pretendPos, limitRooms);
    if (!checkEmptyAdjacentTiles(pretendPos)){
        limitRooms++;
        nextRoom(start, limitRooms);
    }
}

bool Map::checkEmptyAdjacentTiles(std::array<int, 2> pos){
    if (checkPos({pos[0] + 1, pos[1] + 0}) && !m_rooms.at(pos[0] + 1).at(pos[1] + 0)) {
        return true;
    }
    if (checkPos({pos[0] - 1, pos[1] + 0}) && !m_rooms.at(pos[0] - 1).at(pos[1] + 0)){
        return true;
    }
    if (checkPos({pos[0] + 0, pos[1] + 1}) && !m_rooms.at(pos[0] + 0).at(pos[1] + 1)){
        return true;
    }
    if (checkPos({pos[0] + 0, pos[1] - 1}) && !m_rooms.at(pos[0] + 0).at(pos[1] - 1)){
        return true;
    }
    return false;
}

bool Map::checkPos(std::array<int, 2> pos){
    if (pos[0] >= m_rooms.size() || pos[1] >= m_rooms.at(0).size() || pos[0] < 0 || pos[1] < 0){ //continue if upcoming is outside of map
        return false;
    }
    return true;
}

void Map::generateRoom(Room* room){
    int limitRooms = m_roomsNumber;
    std::array<int, 2> start;
    start[0] = rand()%m_rooms.size();
    start[1] = rand()%m_rooms.at(0).size();
    nextRoom(start, limitRooms);
    delete m_rooms.at(start[0]).at(start[1]);
    m_rooms.at(start[0]).at(start[1]) = room;
}

void Map::shortenMap() {
    int minY = m_rooms.size(), maxY = -1, minX = m_rooms.at(0).size(), maxX = -1;
    for (int i = 0; i < m_rooms.size(); i++) {
        for (int j = 0; j < m_rooms.at(i).size(); j++) {
            if (m_rooms.at(i).at(j)){
                if (j < minY){
                    minY = j;
                }
                if (j > maxY){
                    maxY = j;
                }
                if (i < minX){
                    minX = i;
                }
                if (i > maxX){
                    maxX = i;
                }
            }
        }
    }
    for (int i = 0; i < m_rooms.size(); i++) {
        m_rooms.at(i).erase(m_rooms.at(i).begin(), m_rooms.at(i).begin() + minY);
        m_rooms.at(i).erase(m_rooms.at(i).begin() + maxY - minY + 1, m_rooms.at(i).end());
    }
    m_rooms.erase(m_rooms.begin(), m_rooms.begin() + minX);
    m_rooms.erase(m_rooms.begin() + maxX - minX + 1, m_rooms.end());

}

void Map::printMinimap(){
    HANDLE console_color;
    console_color = GetStdHandle(STD_OUTPUT_HANDLE);
    for (int i = 0; i < m_rooms.size(); i++) {
        for (int j = 0; j < m_rooms.at(i).size(); j++) {
            if (!m_rooms.at(i).at(j)){
                std::cout << "  ";
            } else {
                int color = 0;
                if (m_rooms.at(i).at(j)->getPlayer()){
                    color =+ (int)Colors::DarkBlue * 16 + 0;
                }
                if (m_rooms.at(i).at(j)->getSize()[0] > 10){
                    color +=  0 * 16 + (int)Colors::LightPurple;
                } else {
                    color += 0 * 16 + (int)Colors::LightGreen;
                }
                SetConsoleTextAttribute(console_color, color);
                std::cout << "[]";
            }
            SetConsoleTextAttribute(console_color, (int)Colors::Black * 16 + (int)Colors::White);
        }
        std::cout << std::endl;
    }
}

Room* Map::newRoom(){
    std::string roomSize = (rand()%2 ? "M" : "V");
    std::string fileName = "roomky/room" + roomSize + std::to_string(rand()%10 + 1) + ".txt";
    std::ifstream in(fileName);
    std::string line;
    std::vector<std::vector<std::string>> roomContent;
    std::vector<Enemy*> enemies;
    std::vector<Item*> items;
    while (std::getline(in, line)){
        std::vector<std::string> row;
        for (int i = 0; i < line.size(); i++) {
            row.push_back(line.substr(i, 1));
        }
        roomContent.push_back(row);
    }
    for (int i = 0; i < roomContent.size(); i++) {
        for (int j = 0; j < roomContent.at(i).size(); j++) {
            if (roomContent.at(i).at(j) == "M"){
                enemies.push_back(new Enemy(5,5,5,5,10,{i, j})); // TODO balance enemy
            }
            if (roomContent.at(i).at(j) == "?"){
                Item *item;
                int itemtype = rand()%3;
                switch (itemtype) {
                    case 0:
                        item = new Item(ItemType::Sword, ItemQuality::Common, rand()%3+1, rand()%2+1, rand()%4+1, 0, {i, j});//TODO randomizace
                        break;
                    case 1:
                        item = new Item(ItemType::Armor, ItemQuality::Common, rand()%3+1, rand()%4+1, 0, rand()%3*10, {i, j});//TODO randomizace
                        break;
                    default:
                        item = new Item(ItemType::Potion, ItemQuality::Common, 0, 0, 0, rand()%10+10, {i, j});//TODO randomizace
                        break;
                }
                int itemqual = rand()%100+1;
                if (itemqual <= 50 && item->getType() != ItemType::Potion){
                    item->setQuality(ItemQuality::Uncommon);
                    item->setAgility(item->getAgility()*1.5+1);
                    item->setDefence(item->getDefence()*1.5+1);
                    item->setStrength(item->getStrength()*1.5+1);
                    item->setHealth(item->getHealth()*1.5+1);
                    if (itemqual <= 25){
                        item->setQuality(ItemQuality::Rare);
                        item->setAgility(item->getAgility()*1.2+1);
                        item->setDefence(item->getDefence()*1.2+1);
                        item->setStrength(item->getStrength()*1.2+1);
                        item->setHealth(item->getHealth()*1.2+1);
                        if (itemqual <= 10){
                            item->setQuality(ItemQuality::Epic);
                            item->setAgility(item->getAgility()*1.2+1);
                            item->setDefence(item->getDefence()*1.2+1);
                            item->setStrength(item->getStrength()*1.2+1);
                            item->setHealth(item->getHealth()*1.2+1);
                            if (itemqual <= 2){
                                item->setQuality(ItemQuality::Legendary);
                                item->setAgility(item->getAgility()*1.1+1);
                                item->setDefence(item->getDefence()*1.1+1);
                                item->setStrength(item->getStrength()*1.1+1);
                                item->setHealth(item->getHealth()*1.1+1);
                            }
                        }
                    }
                }
                items.push_back(item);
            }
        }
    }
    Room* room = new Room(roomContent, {(int)roomContent.size(),(int)roomContent.at(0).size()}, enemies, items, nullptr);
    return room;
}

Room* Map::firstRoom(){
    std::ifstream in("roomky/roomM0.txt");
    Player* player = new Player(baseAgility, baseDefence, baseHealth, baseStrength, baseMaxHealth, {4,4}, baseLuck, baseXpMax, baseXp, baseLevel, baseSkillPoint, baseRevives);
    std::string line;
    std::vector<std::vector<std::string>> roomContent;
    while (std::getline(in, line)){
        std::vector<std::string> row;
        for (int i = 0; i < line.size(); i++) {
            row.push_back(line.substr(i, 1));
        }
        roomContent.push_back(row);
    }
    std::vector<Enemy*> enemies;
    std::vector<Item*> items;
    Room* room = new Room(roomContent, {(int)roomContent.size(),(int)roomContent.at(0).size()}, enemies, items, player);
    return room;
}

void Map::connectRooms(){
    for (int i = 0; i < m_rooms.size(); i++) {
        for (int j = 0; j < m_rooms.at(i).size(); j++) {
            if (!m_rooms.at(i).at(j)){
                continue;
            }
            if (checkPos({i + 1, j + 0}) && m_rooms.at(i + 1).at(j + 0)) {
                m_rooms.at(i).at(j)->setDown(m_rooms.at(i + 1).at(j + 0));
            }
            if (checkPos({i - 1, j + 0}) && m_rooms.at(i - 1).at(j + 0)){
                m_rooms.at(i).at(j)->setUp(m_rooms.at(i - 1).at(j + 0));
            }
            if (checkPos({i + 0, j + 1}) && m_rooms.at(i + 0).at(j + 1)){
                m_rooms.at(i).at(j)->setRight(m_rooms.at(i + 0).at(j + 1));
            }
            if (checkPos({i + 0, j - 1}) && m_rooms.at(i + 0).at(j - 1)){
                m_rooms.at(i).at(j)->setLeft(m_rooms.at(i + 0).at(j - 1));
            }
        }
    }
}

bool Map::checkEndGame(Room* room){
    if (room->checkCompleted()){
        m_completedRooms++;
    }
    if (m_completedRooms == m_roomsNumber){
        return true;
    }
    return false;
}

Map::~Map() {
    for (std::vector<Room*> roomRow: m_rooms) {
        for (Room* room: roomRow) {
            if (!room){
                continue;
            }
            delete room;
        }
    }
}