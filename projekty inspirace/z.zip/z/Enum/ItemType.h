//
// Created by filip on 25.12.2022.
//

#ifndef PROJECTX_ITEMTYPE_H
#define PROJECTX_ITEMTYPE_H

enum class ItemType{
    Sword,
    Potion,
    Armor,
    Gold
};

#endif //PROJECTX_ITEMTYPE_H
