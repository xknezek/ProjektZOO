//
// Created by filip on 09.11.2022.
//

#ifndef PROJECTX_ROOM_H
#define PROJECTX_ROOM_H
#include <array>
#include <iostream>
#include <vector>
#include "../Entities/Enemy.h"
#include "../Inventory/Item.h"
#include "../Entities/Player.h"
/**
 * Room class is for moving inside of room and basic mechanics of a game. Spawning of enemies, items and room content.
 */
class Room {
private:
    Room* m_left;
    Room* m_right;
    Room* m_up;
    Room* m_down;
    std::array<int, 2> m_size;
    std::vector<Enemy*> m_enemies;
    std::vector<Item*> m_items;
    Player* m_player;
    std::vector<std::vector<std::string>> m_roomContent;
public:
/**
 * Constructor for room.
 * @param left
 * @param right
 * @param up
 * @param down
 * @param size
 * @param enemies
 * @param items
 * @param player
 */
Room(Room* left, Room* right, Room* up, Room* down, std::vector<std::vector<std::string>> roomContent, std::array<int, 2> size, std::vector<Enemy*> enemies, std::vector<Item*> items, Player* player);

/**
 *
 * @param size
 * @param enemies
 * @param items
 * @param player
 */
Room(std::vector<std::vector<std::string>> roomContent, std::array<int, 2> size, std::vector<Enemy*> enemies, std::vector<Item*> items, Player* player);

    /**
     * Function to get the room on the left of current the room.
     * @return Returns room on the left of the current room.
     */
    Room* getLeft();

    /**
     * Function to get the room on the right of the current room.
     * @return Returns room on the right of the current room.
     */
    Room* getRight();
    /**
     * Function to get the room above the current room.
     * @return Returns room above the current room.
     */
    Room* getUp();

    /**
     * Function to get the room below the current room.
     * @return Returns room below the current room.
     */
    Room* getDown();

    /**
     * Void function to set room on the left of the current room and create doorway.
     * @param room Room on the left.
     */
    void setLeft(Room* room);

    /**
     * Void function to set room on the right of the current room and create doorway.
     * @param room Room on the right.
     */
    void setRight(Room* room);

    /**
     * Void function to set room above the current room and create doorway.
     * @param room Room above.
     */
    void setUp(Room* room);

    /**
     * Void function to set room below the current room and create doorway.
     * @param room Room below.
     */
    void setDown(Room* room);

    /**
     * Function to get the size of a room.
     * @return Returns size of a room.
     */
    std::array<int, 2> getSize();

    /**
     * Function to get the amount of enemies in the room.
     * @return Returns vector of enemies in the room.
     */
    std::vector<Enemy*> getEnemies();

    /**
     *Function to get the amount of items in the room.
     * @return returns vector of items in the room.
     */
    std::vector<Item*> getItems();

    /**
     * Function to get the contents of each tile.
     * @param pos Position of tile.
     * @return Returns contents of each tile.
     */
    std::string getTile(std::array<int, 2> pos);

    /**
     * Void function to set player' info.
     * @param player Player's info.
     */
    void setPlayer(Player* player);

    /**
     * Function to get player's info.
     * @return Returns player's info.
     */
    Player* getPlayer();

    /**
     * Void function to drop items from inventory on the room floor.
     * @param item Value based on selected item.
     */
    void dropItem(Item* item);

    /**
     * Function to pick up item from the room floor.
     * @param item Value based on spawned item.
     * @return Returns picked up item.
     */
    Item* pickItem(Item* item);

    /**
     * Void function to set the contents of each tile.
     * @param pos Position of tile.
     * @param tile Content of the tile.
     */
    void setTile(std::array<int, 2> pos, std::string tile);

    /**
     * Bool function to check the player's position.
     * @param pos Player's position.
     * @return Returns if the player can move in that direction.
     */
    bool checkPos(std::array<int, 2> pos);

    /**
     * Function to find empty positions next to the player for dropping items.
     * @param circle Player's surroundings.
     * @param pos Value based on player's position.
     * @return Returns empty tiles around the player.
     */
    std::array<int, 2> checkEmptyNeighbourPosition(int circle, std::array<int, 2> pos);

    /**
     * Virtual destructor for room.
     */
    virtual ~Room();

    /**
     * Void function for setting enemy's stats.
     * @param enemy Enemy stats.
     * @param index Which enemy in the room.
     */
    void setEnemy(Enemy* enemy,int index);

    /**
     * Bool function to check if there are no enemies remaining in the room.
     * @return Returns true if the room is empty. False if it's not.
     */
    bool checkCompleted();
};


#endif //PROJECTX_ROOM_H
