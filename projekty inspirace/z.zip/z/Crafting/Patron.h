//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_PATRON_H
#define PROJECTX_PATRON_H
#include "../Enum/ItemQuality.h"
#include "../Map/Room.h"
#include "../Inventory/Inventory.h"
#include "../Entities/Player.h"

/**
 * Class for crafting with patron.
 */
class Patron {

private:
    Player* m_player;
    Item *first;
    Item *second;

    /**
     * Void function to delete items used for crafting from player's inventory.
     */
    void clearUsed();

    /**
     * Bool function to check if the player has enough items in the same type and quality needed for crafting.
     * @param index Value based on position in player's inventory.
     * @return Returns true if he has. False if he hasn't.
     */
    bool quantityCheck(int index);
public:
    /**
     * Constructor for patron.
     */
    Patron();

    /**
     * Bool function for crafting
     * @param index Value based on position in player's inventory.
     * @param player Addresses the player from memory.
     * @return Returns true if the item can be crafted. False if it can't.
     */
    bool craftByQuality(int index, Player* player);

};


#endif //PROJECTX_PATRON_H
