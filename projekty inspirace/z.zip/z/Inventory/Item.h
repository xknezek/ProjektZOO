//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_ITEM_H
#define PROJECTX_ITEM_H

#include <iostream>
#include <array>
#include "../Enum/ItemQuality.h"
#include "../Enum/ItemType.h"

/**
 * Item class for type, quality, agility, defence, strength, health and position of item.
 */
class Item {
private:
    static int m_count;
    int m_id;
    int m_agility, m_defence, m_strength, m_health;
    ItemType m_type;
    ItemQuality m_quality;
    std::array<int, 2> m_pos;
    bool m_equipped;
public:

/**
 * Item constructor
 * @param type
 * @param quality
 * @param agility
 * @param defence
 * @param strength
 * @param health
 * @param pos
 */
    Item(ItemType type, ItemQuality quality, int agility, int defence, int strength, int health,
         std::array<int, 2> pos);

    Item(int goldValue);

    /**
     * Int function to get item's id.
     * @return Returns item's id.
     */
    int getId();

    /**
     * Function to get the type of item.
     * @return Returns the type of item.
     */
    ItemType getType();

    /**
     * Function to get the quality of item.
     * @return Returns item's quality.
     */
    ItemQuality getQuality();

    /**
     * Int function to get item's agility stat.
     * @return Returns item's agility stat.
     */
    int getAgility();

    /**
     * Int function to get item's defence stat.
     * @return Returns item's defence stat.
     */
    int getDefence();

    /**
     * Int function to get item's strength stat.
     * @return Returns item's strength stat.
     */
    int getStrength();

    /**
     * Int function to get item's health stat.
     * @return Returns item's health stat.
     */
    int getHealth();

    /**
     * Function to get item's position in room.
     * @return Return item's position.
     */
    std::array<int, 2> getPos();

    /**
     * Void function to set item's position.
     * @param pos Position of item in the room.
     */
    void setPos(std::array<int, 2> pos);

    /**
     * Void function to equip items.
     * @param equip Returns true if the item is equipped. False if the item isn't equipped.
     */
    void setEquip(bool equip);

    /**
     * Void function to know if the item is equipped.
     * @return Returns true if the item is equipped. False if the item isn't equipped.
     */
    bool isEquipped();

    /**
     * Void function to set item's health stat.
     * @param health Value of item's health stat.
     */
    void setHealth(int health);

    /**
     * Void function to set item's strength stat
     * @param strength Value of item's strength stat.
     */
    void setStrength(int strength);

    /**
     * Void function to set item's agility stat
     * @param agility Value of item's agility stat.
     */
    void setAgility(int agility);

    /**
     * Void function to set item's defence stat
     * @param defence Value of item's defence stat.
     */
    void setDefence(int defence);

    /**
     * Void function to set item's quality stat
     * @param qualityValue of item's quality stat.
     */
    void setQuality(ItemQuality quality);
};

//int Item::m_id = 0;
#endif //PROJECTX_ITEM_H
