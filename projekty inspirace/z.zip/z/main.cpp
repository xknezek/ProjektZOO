#include <iostream>
#include <time.h>
#include <cstdio>
#include "Game.h"
#include "Inventory/Inventory.h"
int Item::m_count=0;
int Enemy::m_count = 0;

int main() {
    srand(time(NULL));
    Game* game = new Game();
    game->menu();

    delete game;
    return 0;

}
