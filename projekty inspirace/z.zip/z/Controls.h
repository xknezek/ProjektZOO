//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_CONTROLS_H
#define PROJECTX_CONTROLS_H

#include "Entities/Entity.h"
#include "Map/Room.h"
#include <array>
/**
 * Class for player's movement.
 */
class Controls {

public:
    /**
     * Function to get player's input and move him around the map.
     * @param entity Player's movement.
     * @param input Player's input.
     * @param room Current room.
     * @return Returns null pointer or balanced enemy.
     */
    static Enemy* Movement(Entity* entity,char input,Room* room);

};


#endif //PROJECTX_CONTROLS_H
