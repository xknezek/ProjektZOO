//
// Created by czem1 on 07.12.2022.
//

#ifndef PROJECTX_LIGHT_H
#define PROJECTX_LIGHT_H
#include "Attack.h"
#include "time.h"
/**
 *
 */
class Light:public Attack{
public:
    /**
     * Constructor for light attack.
     * @param player Player's stats.
     * @param enemy Enemy's stats.
     */
    Light(Player* player, Enemy* enemy);

    /**
     * Void function for calculating the damage received from an enemy.
     */
    void calcEnemyDmg();

    /**
     * Void function for calculating the damage given by the player.
     */
    void calcPlayerDmg();
};


#endif //PROJECTX_LIGHT_H
