//
// Created by czem1 on 06.12.2022.
//

#ifndef PROJECTX_INVENTORY_H
#define PROJECTX_INVENTORY_H
#include "Item.h"
#include <vector>
class Inventory {
private:
    const int baseInventorySize = 5;
    std::vector<Item*>m_inventory;
public:

    /**
     *Constructor of Inventory.
     */
    Inventory();

    /**
     *Function to get m_inventory of a player.
     @return Returns value of every item in inventory
     */
    std::vector<Item*>getInventory();

    /**
     *Function to level up inventory of a player.
     */
    void lvlUp();

    /**
     *Function to add item from player's inventory.
     * @param item Value based on item's ID.
     * @void does not return any value.
     */
    bool addItem(Item * item);

    /**
     *Function to equip item from player's inventory.
     * @param item Value based on item's ID.
     * @void does not return any value. Cares mainly about logic of equipping items.
     */
    void equipItem(Item* item);

    /**
     *Function to drop item from player's inventory.
     * @param item Value based on item's ID.
     * @return Returns item chosen to drop.
     */
    Item* dropItem(Item* item);

};


#endif //PROJECTX_INVENTORY_H
