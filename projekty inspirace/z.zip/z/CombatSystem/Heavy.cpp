//
// Created by czem1 on 07.12.2022.
//
#include "Heavy.h"
Heavy::Heavy(Player* player, Enemy* enemy):Attack(player, enemy, 16, 0.6 ){

}

void Heavy::calcPlayerDmg() {
    if (rand() % 100 <= (int)(100 * m_attackAffinity + ((m_player->getTotalAgility() - m_enemy->getTotalDefence())))) {
        m_enemy->setHealth(int(m_enemy->getHealth()-std::max(m_player->getTotalStrength()/m_enemy->getTotalDefence() * m_damageAffinity - m_enemy->getTotalDefence()/m_player->getTotalStrength(), float(0))));
    }
}

void Heavy::calcEnemyDmg() {
    if (rand() % 100 <= (int)(100 * m_attackAffinity + ((m_enemy->getTotalAgility() - m_player->getTotalDefence())))) {
        m_player->setHealth(int(m_player->getHealth()-std::max(m_enemy->getTotalStrength() / m_player->getTotalDefence() * m_damageAffinity - m_player->getTotalDefence() / m_enemy->getTotalStrength(), float(0))));
    }
}