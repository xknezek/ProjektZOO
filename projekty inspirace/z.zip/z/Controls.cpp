//
// Created by lucka on 11/4/2022.
//

#include "Controls.h"
Enemy* Controls::Movement(Entity* entity, char input, Room* room) {
    std::array<int,2>position=entity->getPosition();
    switch (input) {
        case 'w':
            position[0]--;
            break;
        case's':
            position[0]++;
            break;
        case 'a':
            position[1]--;
            break;
        case 'd':
            position[1]++;
            break;
        default:
            break;
    }

    if(room->getTile(position)==" "){
        entity->setPosition(position);
    }
    if(room->getTile(position)=="?"){
        int itemIndex;
        for (int i = 0; i < room->getItems().size(); i++) {
            if(room->getItems().at(i)->getPos()==position){
                itemIndex=i;
            }
        }
        if(entity->addItem(room->getItems().at(itemIndex))){
            room->pickItem(room->getItems().at(itemIndex));
            room->setTile(position," ");
            entity->setPosition(position);
        }

    }
    if(room->getTile(position)=="M")
    {

        int eAgility= std::max(rand()%10+room->getPlayer()->getAgility() - (rand()%5+8), 1);
        int eStrength= std::max(rand()%10+room->getPlayer()->getTotalDefence() - (rand()%5+8), 1);
        int eDefence= std::max(rand()%10+room->getPlayer()->getTotalStrength() - (rand()%5+8), 1);
        int eHealth= rand()%10+room->getPlayer()->getMaxHealth();
        Enemy* balancedEnemy=new Enemy(eAgility,eDefence,eHealth,eStrength,eHealth,position);
        for (int i = 0; i < room->getEnemies().size(); i++) {
            if(room->getEnemies().at(i)->getPosition()==position){
                room->setEnemy(balancedEnemy,i);
            }
        }
        return balancedEnemy;

    }
    return nullptr;
}