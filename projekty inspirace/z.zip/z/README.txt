This game was created by Filip Steinmetz, Michal Kadlec, Jakub Knezek, and Peter Helmeci for educational purposes.
It's based on a classic dungeon crawler games. However, the character and items are scalable.
As well as monsters which are getting stronger.
The game takes place in rooms randomly generated on the minimap, waiting for a player to explore them.

Movement is controlled by W, A, S, D.
Press E for inventory and M for map.
Enjoy <3.