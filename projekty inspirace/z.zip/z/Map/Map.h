//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_MAP_H
#define PROJECTX_MAP_H

#include "Room.h"
#include <cstdio>
#include <fstream>
#include <array>
#include <iostream>
#include <vector>
#include <filesystem>
#include <math.h>
#include "../Enum/ItemType.h"
#include "../Enum/Colors.h"
#include <windows.h>

/**
 * Class for map and generation of it.
 */
class Map {
private:
    Room* m_firstRoom;
    int m_roomsNumber;
    int m_completedRooms;

     /**
     * Room in vector in vector.
     * Size of map correlates with \a m_roomsNumber.
     * Constructor fills \a m_map with zeros.
     */
    std::vector<std::vector<Room*>> m_rooms;

    /**
     * Void function that generates map.
     */
    void mapGen();

    /**
     * Void function that generates new room.
     * @param room Number of rooms.
     */
    void generateRoom(Room* room);

    /**
     * Method generates first room and returns it.
     * @return First generated room.
     */
    Room* firstRoom();

    /**
     * Void function that subtracts one from \a LimitRooms and changes zero to one in \a m_map on \a start position.
     * @param start Position of room generated on the map.
     * @param limitRooms Number of remaining rooms to generate.
     */
    void nextRoom(std::array<int, 2> start, int& limitRooms);

    /**
     * Bool function that determines whether is \a pos located inside of a map.
     * @param pos Array that contains x and y coordinates of position.
     * @return True when located inside of map.\n  False when located outside of map.
     */
    bool checkPos(std::array<int, 2> pos);

    /**
     * Checks whether there is located one or zero next to \a pos.
     * @param pos Array that contains x and y coordinates of position.
     * @return True when there is located one or zero.\n  False when there is end of array.
     */
    bool checkEmptyAdjacentTiles(std::array<int, 2> pos);

    /**
     * Function for room generation.
     * @return Returns generated room.
     */
    Room* newRoom();

    /**
     * Connects rooms.
     */
    void connectRooms();

    /**
     * Deletes empty rows and columns in the vector of vector of rooms.
     */
    void shortenMap();
public:

    /**
     * Constructor that creates \a m_map in correlation with amount of rooms.
     * @param roomsNumber Int value.
     */
    Map(int roomsNumber);

    /**
     * Returns current room.
     * @return Current room.
     */
    Room* getMap();

    /**
     * Void function that prints minimap and players position.
     */
    void printMinimap();

    /**
     * Bool function to check if all rooms are cleared of enemies.
     * @param room
     * @return Returns true if the rooms are cleared. Returns false if the rooms aren't cleared.
     */
    bool checkEndGame(Room* room);

    /**
     * Destructor for map.
     */
    ~Map();
};


#endif //PROJECTX_MAP_H
