//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_SAVE_H
#define PROJECTX_SAVE_H


class Save {

};


#endif //PROJECTX_SAVE_H
