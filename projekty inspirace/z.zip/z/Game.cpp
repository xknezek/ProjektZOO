//
// Created by lucka on 11/4/2022.
//

#include "Game.h"


Game::Game() {
    buffer = "";
    SetConsoleOutputCP(65001);
    console_output = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(console_output, &cursorInfo);
    cursorInfo.bVisible = false; // set the cursor visibility
    SetConsoleCursorInfo(console_output, &cursorInfo);
    m_exit = false;
    m_roomsCount = 10;
    keyHit = std::thread(&Game::GetCh, this);
    m_room = nullptr;
    m_map = nullptr;
    m_patron = nullptr;
    m_playerTurn = true;
}

void Game::printRoom() {
    std::array<int, 2> roomSize = m_room->getSize();
    bool entity;
    SetConsoleCursorPosition(console_output, {0, 0});
    for (int i = 0; i < m_room->getSize().at(0); i++) {
        for (int j = 0; j < m_room->getSize().at(1); j++) {
            //std::cout << m_firstRoom->getTile({i,j});
            //printf("\u2588");
            entity = false;
            if (m_room->getTile({i, j}) == "#") {
                SetConsoleTextAttribute(console_output, (int) Colors::LightBlack * 16 + 0);
                std::cout << "  ";
            } else {
                for (int k = 0; k < m_room->getEnemies().size(); k++) {
                    if (m_room->getEnemies().at(k)->getPosition()[0] == i &&
                        m_room->getEnemies().at(k)->getPosition()[1] == j) {
                        //printf( isPlayerTurn ? (isLarge ? "E" : "e") : "E");
                        SetConsoleTextAttribute(console_output,
                                                !isPlayerTurn ? (isLarge ? (int) Colors::LightRed * 16 + 0 :
                                                                 (int) Colors::DarkRed * 16 + 0) :
                                                (int) Colors::LightRed * 16 + 0);
                        std::cout << "  ";
                        entity = true;
                        break;
                    }
                }
                if (m_room->getPlayer()->getPosition()[0] == i && m_room->getPlayer()->getPosition()[1] == j) {
                    //printf( isPlayerTurn ? (isLarge ? "P" : "p") : "P");
                    SetConsoleTextAttribute(console_output,
                                            isPlayerTurn ? (isLarge ? (int) Colors::LightPurple * 16 + 0 :
                                                            (int) Colors::DarkPurple * 16 + 0) :
                                            (int) Colors::LightPurple * 16 + 0);
                    std::cout << "  ";
                    entity = true;
                    continue;
                }
                for (int k = 0; k < m_room->getItems().size(); k++) {
                    if (m_room->getItems().at(k)->getPos()[0] == i && m_room->getItems().at(k)->getPos()[1] == j) {
                        //TODO recolor "?" by rarity
                        ItemQuality itemQuality = m_room->getItems().at(k)->getQuality();
                        int textColor = 15;
                        switch (itemQuality) {
                            case ItemQuality::Common:
                                textColor = (int) Colors::DarkGreen;
                                break;
                            case ItemQuality::Uncommon:
                                textColor = (int) Colors::LightGreen;
                                break;
                            case ItemQuality::Rare:
                                textColor = (int) Colors::DarkPurple;
                                break;
                            case ItemQuality::Epic:
                                textColor = (int) Colors::LightPurple;
                                break;
                            case ItemQuality::Legendary:
                                textColor = (int) Colors::DarkYellow;
                                break;
                        }
                        //printf("?");
                        SetConsoleTextAttribute(console_output, (int) Colors::LightBlue * 16 + textColor);
                        std::cout << "??";
                        entity = true;
                        break;
                    }
                }
                if (m_room->getTile({i, j}) == " " && !entity) {
                    //printf("%s", m_room->getTile({i, j}).c_str());
                    SetConsoleTextAttribute(console_output, (int) Colors::DarkWhite * 16 + 0);
                    std::cout << "  ";
                }
            }
        }
        SetConsoleTextAttribute(console_output, (int) Colors::Black * 16 + (int) Colors::White);
        std::cout << std::endl;
    }
}

void Game::printMinimap() {
    system("cls");
    m_map->printMinimap();
}

void Game::printInventory() {
    system("cls");
    int index = 0;
    char input = EOF;
    while (input != 27 && input != 'e') {
        SetConsoleCursorPosition(console_output, {0, 0});
        if (buffer.empty()) {
            input = EOF;
        }
        if (!buffer.empty()) {
            m.lock();
            input = buffer[0];
            buffer.erase(0);
            m.unlock();
        }
        switch (input) {
            case 'a' :
                index--;
                if (index < 0) { index = m_room->getPlayer()->getInventory().size() - 1; }
                system("cls");
                break;
            case 'd' :
                index++;
                if (index > m_room->getPlayer()->getInventory().size() - 1) { index = 0; }
                system("cls");
                break;
            case 'q' :
                m_room->dropItem(m_room->getPlayer()->dropItem(m_room->getPlayer()->getInventory().at(index)));
                m_room->getPlayer()->getInventory().at(index) = nullptr;
                system("cls");
                break;
            case 'r' :
                spendSkillPoint();
                system("cls");
                break;
            case 'c':
                m_patron->craftByQuality(index, m_room->getPlayer());
                system("cls");
                break;
            case 13 :
                if (m_room->getPlayer()->getInventory().at(index)) {
                    if (m_room->getPlayer()->getInventory().at(index)->getType() == ItemType::Gold) {
                        break;
                    }
                    m_room->getPlayer()->equipItem(m_room->getPlayer()->getInventory().at(index));
                    system("cls");
                }
                break;
        }
        for (int i = 0; i < m_room->getPlayer()->getInventory().size(); i++) {
            if (!m_room->getPlayer()->getInventory().at(i)) {
                SetConsoleTextAttribute(console_output,
                                        (index == i ? (int) Colors::DarkWhite : (int) Colors::Black) * 16 +
                                        (int) Colors::White);
                std::cout << "_|";
                SetConsoleTextAttribute(console_output, (int) Colors::Black * 16 + (int) Colors::White);
                continue;
            }
            ItemQuality itemQuality = m_room->getPlayer()->getInventory().at(i)->getQuality();
            int textColor = (int) Colors::White;
            switch (itemQuality) {
                case ItemQuality::Common:
                    textColor = (int) Colors::DarkGreen;
                    break;
                case ItemQuality::Uncommon:
                    textColor = (int) Colors::LightGreen;
                    break;
                case ItemQuality::Rare:
                    textColor = (int) Colors::DarkPurple;
                    break;
                case ItemQuality::Epic:
                    textColor = (int) Colors::LightPurple;
                    break;
                case ItemQuality::Legendary:
                    textColor = (int) Colors::DarkYellow;
                    break;
            }
            SetConsoleTextAttribute(console_output,(index == i ? (int) Colors::DarkWhite : (int) Colors::Black) * 16 + textColor);
            switch (m_room->getPlayer()->getInventory().at(i)->getType()) {
                case ItemType::Armor:
                    std::cout << "Armor|";
                    break;
                case ItemType::Gold:
                    std::cout << "Gold|";
                    break;
                case ItemType::Potion:
                    std::cout << "Potion|";
                    break;
                case ItemType::Sword:
                    std::cout << "Sword|";
                    break;
            }
            SetConsoleTextAttribute(console_output, (int) Colors::Black * 16 + (int) Colors::White);
        }
        if (m_room->getPlayer()->getInventory().at(index)) {
            std::cout << std::endl << std::endl;
            if (m_room->getPlayer()->getInventory().at(index)->getType() != ItemType::Gold) {
                if (m_room->getPlayer()->getInventory().at(index)->getType() != ItemType::Potion){
                    std::cout << "Equipped: " << (m_room->getPlayer()->getInventory().at(index)->isEquipped() ? "Yes" : "No") << std::endl;
                }
                switch (m_room->getPlayer()->getInventory().at(index)->getQuality()) {
                    case ItemQuality::Common:
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::DarkGreen));
                        std::cout << "Common" << std::endl;
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::White));
                        break;
                    case ItemQuality::Uncommon:
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::LightGreen));
                        std::cout << "Uncommon" << std::endl;
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::White));
                        break;
                    case ItemQuality::Rare:
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::DarkPurple));
                        std::cout << "Rare" << std::endl;
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::White));
                        break;
                    case ItemQuality::Epic:
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::LightPurple));
                        std::cout << "Epic" << std::endl;
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::White));
                        break;
                    case ItemQuality::Legendary:
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::DarkYellow));
                        std::cout << "Legendary" << std::endl;
                        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::White));
                        break;
                }
                if (m_room->getPlayer()->getInventory().at(index)->getStrength() > 0) {
                    std::cout << "Strength: " << m_room->getPlayer()->getInventory().at(index)->getStrength() << std::endl;
                }
                if (m_room->getPlayer()->getInventory().at(index)->getAgility() > 0) {
                    std::cout << "Agility: " << m_room->getPlayer()->getInventory().at(index)->getAgility() << std::endl;
                }
                if (m_room->getPlayer()->getInventory().at(index)->getDefence() > 0) {
                    std::cout << "Defence: " << m_room->getPlayer()->getInventory().at(index)->getDefence() << std::endl;
                }
                if (m_room->getPlayer()->getInventory().at(index)->getHealth() > 0) {
                    std::cout << "Health: " << m_room->getPlayer()->getInventory().at(index)->getHealth() << std::endl;
                }
            } else {
                std::cout << "Value: " << m_room->getPlayer()->getInventory().at(index)->getHealth() << std::endl;
            }
        }
        std::cout << std::endl << std::endl << "Player stats: " << std::endl;
        std::cout << "Health: " << m_room->getPlayer()->getHealth() << "/" << m_room->getPlayer()->getTotalMaxHealth()
                  << std::endl;
        std::cout << "Strength: " << m_room->getPlayer()->getStrength() << "(+"
                  << m_room->getPlayer()->getTotalStrength() - m_room->getPlayer()->getStrength() << ")" << std::endl;
        std::cout << "Defence: " << m_room->getPlayer()->getDefence() << "(+"
                  << m_room->getPlayer()->getTotalDefence() - m_room->getPlayer()->getDefence() << ")" << std::endl;
        std::cout << "Agility: " << m_room->getPlayer()->getAgility() << "(+"
                  << m_room->getPlayer()->getTotalAgility() - m_room->getPlayer()->getAgility() << ")" << std::endl;
        std::cout << "Luck: " << m_room->getPlayer()->getLuck() * 100 << "%" << std::endl;
        std::cout << "Revives: " << m_room->getPlayer()->getRevives() << std::endl << std::endl;
        std::cout<< "Press C to craft item out of your inventory"<<std::endl;
        std::cout << "You have: " << m_room->getPlayer()->getSkillPoint() << " skill points. Press R to use." << std::endl;
        std::cout << "Your level: " << m_room->getPlayer()->getLevel() << "      your xp:"<<m_room->getPlayer()->getXp()<<"/"<<m_room->getPlayer()->getMaxXP()  <<std::endl;

    }
}

void Game::spendSkillPoint() {
    system("cls");
    int index = 0;
    char input = EOF;
    while (input != 27) {
        SetConsoleCursorPosition(console_output, {0, 0});
        if (buffer.empty()) {
            input = EOF;
        }
        if (!buffer.empty()) {
            m.lock();
            input = buffer[0];
            buffer.erase(0);
            m.unlock();
        }
        switch (input) {
            case 'w' :
                index--;
                if (index < 0) { index = 5; }
                system("cls");
                break;
            case 's' :
                index++;
                if (index > 5) { index = 0; }
                system("cls");
                break;
            case 13 :
                m_room->getPlayer()->skillPointAdd(index);
                system("cls");
                break;
        }
        std::array<std::string, 6> abilities = {"Max Health ", "Strength ", "Defence ", "Agility ", "Luck ",
                                                "Revives "};
        std::cout << "Choose level up: " << std::endl;
        for (int i = 0; i < abilities.size(); i++) {
            if (i == index) {
                SetConsoleTextAttribute(console_output, (int) Colors::White * 16 + (int) Colors::Black);
            }
            std::cout << abilities[i];
            switch (i) {
                case 0:
                    std::cout << m_room->getPlayer()->getMaxHealth();
                    break;
                case 1:
                    std::cout << m_room->getPlayer()->getStrength();
                    break;
                case 2:
                    std::cout << m_room->getPlayer()->getDefence();
                    break;
                case 3:
                    std::cout << m_room->getPlayer()->getAgility();
                    break;
                case 4:
                    std::cout << m_room->getPlayer()->getLuck();
                    break;
                case 5:
                    std::cout << m_room->getPlayer()->getRevives();
                    break;
            }
            if (i == index) {
                std::cout << " (++)";
            }
            std::cout << std::endl;
            SetConsoleTextAttribute(console_output, (int) Colors::Black * 16 + (int) Colors::White);
        }
    }
}

char Game::GetCh() {
    HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
    INPUT_RECORD ir;
    DWORD dwEventsRead;
    while (ReadConsoleInputA(hStdin, &ir, 1, &dwEventsRead)) {
        /* Read key press */
        if (ir.EventType == KEY_EVENT && ir.Event.KeyEvent.bKeyDown == false) {
            m.lock();
            buffer.push_back(ir.Event.KeyEvent.uChar.AsciiChar);
            m.unlock();
        }
        if (m_exit) {
            return EOF;
        }
    }
    return EOF;
}

void Game::play() {
    char input = EOF;
    bool lockInput = false;
    start = clock();
    while (true) {
        //timer reset
        if ((clock() - start) / (double(CLOCKS_PER_SEC / 1000)) >= 1000) {
            start = clock();
            isLarge = !isLarge;
            printRoom();
        }
        if (buffer.empty()) {
            input = EOF;
        }
        if (!buffer.empty()) {
            m.lock();
            input = buffer[0];
            buffer.erase(0);
            m.unlock();
        }
        //lock input after pressing one key and then unlocking it after release
        //buffer is filling at slower rate than emptying
        if (input != EOF && !lockInput) {
            lockInput = true;
            if (keyEvent(input)) return;
            isLarge = true;
            printRoom();
            start = clock();
        }
        if (input == EOF && lockInput) {
            lockInput = false;
        }
        if (input == 27) {
            return;
        }
        std::array<int, 2> playerPos = m_room->getPlayer()->getPosition();
        if (playerPos[0] == 0) {
            Player *playerHolder = m_room->getPlayer();
            m_room->setPlayer(nullptr);
            m_room = m_room->getUp();
            playerHolder->setPosition({m_room->getSize()[0] - 2, m_room->getSize()[1] / 2});
            m_room->setPlayer(playerHolder);
            system("cls");
            printRoom();
            continue;
        }
        if (playerPos[1] == 0) {
            Player *playerHolder = m_room->getPlayer();
            m_room->setPlayer(nullptr);
            m_room = m_room->getLeft();
            playerHolder->setPosition({m_room->getSize()[0] / 2, m_room->getSize()[1] - 2});
            m_room->setPlayer(playerHolder);
            system("cls");
            printRoom();
            continue;
        }
        if (playerPos[0] == m_room->getSize()[0] - 1) {
            Player *playerHolder = m_room->getPlayer();
            m_room->setPlayer(nullptr);
            m_room = m_room->getDown();
            playerHolder->setPosition({1, m_room->getSize()[1] / 2});
            m_room->setPlayer(playerHolder);
            system("cls");
            printRoom();
            continue;
        }
        if (playerPos[1] == m_room->getSize()[1] - 1) {
            Player *playerHolder = m_room->getPlayer();
            m_room->setPlayer(nullptr);
            m_room = m_room->getRight();
            playerHolder->setPosition({m_room->getSize()[0] / 2, 1});
            m_room->setPlayer(playerHolder);
            system("cls");
            printRoom();
            continue;
        }
    }
}

void Game::menu() {
    system("cls");
    int index = 1;
    char input = EOF;
    std::array<std::string, 4> options = {"Continue", "New Game", "About", "Exit (press 2x)"};
    while (input != 0) {
        SetConsoleCursorPosition(console_output, {0, 0});
        if (buffer.empty()) {
            input = EOF;
        }
        if (!buffer.empty()) {
            m.lock();
            input = buffer[0];
            buffer.erase(0);
            m.unlock();
        }
        switch (input) {
            case 'w' :
                index--;
                if (index < 0) { index = options.size() - 1; }
                system("cls");
                break;
            case 's' :
                index++;
                if (index > options.size() - 1) { index = 0; }
                system("cls");
                break;
            case 13 :
                switch (index) {
                    case 0:
                        if (m_map) {
                            system("cls");
                            play();
                        }
                        break;
                    case 1:
                        system("cls");
                        newGame();
                        break;
                    case 2:
                        system("cls");
                        about();
                        break;
                    case 3:
                        input = 0;
                        break;
                }
                system("cls");
                break;
        }
        std::cout << "Welcome to our little project" << std::endl;
        for (int i = 0; i < options.size(); i++) {
            if (i == index) {
                SetConsoleTextAttribute(console_output, (int) Colors::White * 16 + (int) Colors::Black);
            }
            std::cout << options[i];
            SetConsoleTextAttribute(console_output, (int) Colors::Black * 16 + (int) Colors::White);
            std::cout << std::endl;
        }
    }
}

void Game::newGame() {
    system("cls");
    if (m_patron){
        delete m_patron;
        m_patron = nullptr;
    }
    if (m_map){
        delete m_map;
        m_map = nullptr;
        m_room = nullptr;
    }
    int index = 0;
    char input = EOF;
    std::array<int, 4> options = {10, 20, 30, 40};
    while (input != 13) {
        SetConsoleCursorPosition(console_output, {0, 0});
        std::cout << "Select number of rooms:" << std::endl;
        if (buffer.empty()) {
            input = EOF;
        }
        if (!buffer.empty()) {
            m.lock();
            input = buffer[0];
            buffer.erase(0);
            m.unlock();
        }
        switch (input) {
            case 'w' :
                index--;
                if (index < 0) { index = options.size() - 1; }
                system("cls");
                break;
            case 's' :
                index++;
                if (index > options.size() - 1) { index = 0; }
                system("cls");
                break;
            case 13 :
                switch (index) {
                    case 0:
                        m_roomsCount = 10;
                        break;
                    case 1:
                        m_roomsCount = 20;
                        break;
                    case 2:
                        m_roomsCount = 30;
                        break;
                    case 3:
                        m_roomsCount = 40;
                        break;
                }
                system("cls");
                break;
            case 27:
                return;
        }
        for (int i = 0; i < options.size(); i++) {
            if (i == index) {
                SetConsoleTextAttribute(console_output, (int) Colors::White * 16 + (int) Colors::Black);
            }
            std::cout << options[i];
            SetConsoleTextAttribute(console_output, (int) Colors::Black * 16 + (int) Colors::White);
            std::cout << std::endl;
        }
    }
    system("cls");
    std::cout << "Loading..." << std::endl;
    m_map = new Map(m_roomsCount);
    m_room = m_map->getMap();
    isPlayerTurn = true;
    isLarge = true;
    m_patron = new Patron();
    play();
}

void Game::about() {
    char input = EOF;
    system("cls");
    std::ifstream in("README.txt");
    std::string line;
    if (!in.is_open()) {
        std::cerr << "Error, cannot open About file.";
        return;
    }
    while (std::getline(in, line)) {
        std::cout << line << std::endl;
    }
    std::cout << std::endl;
    std::cout << "Press any key to continue..." << std::endl;
    while (input == EOF) {
        if (!buffer.empty()) {
            m.lock();
            input = buffer[0];
            buffer.erase(0);
            m.unlock();
        }
    }
    system("cls");
}

bool Game::keyEvent(char input) {
    Enemy *fightingEnemy = nullptr;
    if (input == 'w' || input == 's' || input == 'a' || input == 'd') {
        fightingEnemy = Controls::Movement(m_room->getPlayer(), input, m_room);
    }
    if (input == 'm') {
        input = EOF;
        printMinimap();
        std::cout << "Press \"m\" to close minimap." << std::endl;
        while (input != 'm') {
            if (!buffer.empty()) {
                m.lock();
                input = buffer[0];
                buffer.erase(0);
                m.unlock();
            }
        }
        system("cls");
    }
    if (input == 'e') {
        printInventory();
        system("cls");
    }
    if (fightingEnemy) {
        combatInterface(fightingEnemy);
        if (!m_map){
            return true;
        }
        if (m_map->checkEndGame(m_room)){
            return endGame(true);
        }
    }
    return false;
}

bool Game::combatInterface(Enemy *enemy) {
    m_combat = new Combat(m_room->getPlayer(), enemy, true);
    bool isFled = false;
    system("cls");
    int index = 0;
    char input = EOF;
    std::array<std::string, 4> options = {"Light attack", "Heavy Attack", "Flee",
                                          "Inventory"};
    while (m_room->getPlayer()->getHealth() > 0 && enemy->getHealth() > 0 && !isFled) {
        while (input != 13) {
            SetConsoleCursorPosition(console_output, {0, 0});
            if (buffer.empty()) {
                input = EOF;
            }
            if (!buffer.empty()) {
                m.lock();
                input = buffer[0];
                buffer.erase(0);
                m.unlock();
            }
            switch (input) {
                case 'w' :
                    index--;
                    if (index < 0) {
                        index = options.size() - 1;
                    }
                    system("cls");
                    break;
                case 's' :
                    index++;
                    if (index > options.size() - 1) {
                        index = 0;
                    }
                    system("cls");
                    break;
                case 13 :
                    switch (index) {
                        case 0:
                            m_combat->round(AttackType::Light, true);
                            break;
                        case 1:
                            m_combat->round(AttackType::Heavy, true);
                            break;
                        case 2:
                            isFled = m_combat->flee();
                            break;
                        case 3:
                            printInventory();
                            break;
                    }
                    system("cls");
                    break;
            }
            for (int i = 0; i < options.size(); i++) {
                if (i == index) {
                    SetConsoleTextAttribute(console_output, (int) Colors::White * 16 + (int) Colors::Black);
                }
                std::cout << options[i];
                SetConsoleTextAttribute(console_output, (int) Colors::Black * 16 + (int) Colors::White);
                std::cout << std::endl;
            }
            SetConsoleTextAttribute(console_output, (int) Colors::LightGreen * 16 + (int) Colors::Black);
            std::cout << "Player's health:" << m_room->getPlayer()->getHealth() << "/"
                      << m_room->getPlayer()->getTotalMaxHealth() << std::endl;
            SetConsoleTextAttribute(console_output, (int) Colors::LightRed * 16 + (int) Colors::Black);
            std::cout <<"Enemy's health:" << enemy->getHealth() << "/" << enemy->getTotalMaxHealth() << std::endl;
            /*
            SetConsoleTextAttribute(console_output, (int) Colors::DarkWhite * 16 + (int) Colors::Black);
            std::cout <<"Your strength: "<< m_room->getPlayer()->getStrength() << " your defence:  " << m_room->getPlayer()->getDefence() << std::endl;
            std::cout <<"Enemy's strength: "<< enemy->getStrength() << " " << "Enemy's defence: " << enemy->getDefence() << std::endl;
            */
            SetConsoleTextAttribute(console_output, (int) Colors::Black * 16 + (int) Colors::White);
        }
        int choice = rand() % 2;
        switch (choice) {
            case 0:
                m_combat->round(AttackType::Light, false);
                break;
            case 1:
                m_combat->round(AttackType::Heavy, false);
                break;
        }
        input = EOF;
        system("cls");
    }
    if (enemy->getHealth() <= 0) {
        m_room->setTile(enemy->getPosition(), " ");
        m_room->getPlayer()->setXp(m_room->getPlayer()->getXp()+ std::max(rand()%5+1,int((rand()%5)+m_room->getPlayer()->getLuck()*100))); //TODO balance for xpd
        m_room->getPlayer()->getInventory().at(0)->setHealth(m_room->getPlayer()->getInventory().at(0)->getHealth()+100); //TODO balance for gold
        delete enemy;
    }
    if (m_room->getPlayer()->getHealth() <= 0){
        if(m_room->getPlayer()->getRevives() > 0){
            m_room->getPlayer()->setHealth((int)m_room->getPlayer()->getTotalMaxHealth()*0.6);
            m_room->getPlayer()->setRevives(m_room->getPlayer()->getRevives()-1);
        }
        else{
            delete m_combat;
            return endGame(false);
        }
    }
    system("cls");
    delete m_combat;
    return false;
}

bool Game::endGame(bool win) {
    system("cls");
    if (win){
        SetConsoleTextAttribute(console_output,int(Colors::DarkGreen) * 16 + int(Colors::White));
        std::cout << "GAME OVER\nYou cleared all rooms." << std::endl;
        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::White));
    } else {
        SetConsoleTextAttribute(console_output,int(Colors::DarkRed) * 16 + int(Colors::White));
        std::cout << "GAME OVER\nYou died." << std::endl;
        SetConsoleTextAttribute(console_output,int(Colors::Black) * 16 + int(Colors::White));
    }
    std::cout << "Press any key to continue..." << std::endl;
    delete m_patron;
    delete m_map;
    m_patron = nullptr;
    m_map = nullptr;
    m_room = nullptr;
    char input = EOF;
    while (input == EOF) {
        if (!buffer.empty()) {
            m.lock();
            input = buffer[0];
            buffer.erase(0);
            m.unlock();
        }
    }
    return true;
}

Game::~Game() {
    m_exit = true;
    keyHit.join();
    delete m_patron;
    delete m_room;
    delete m_map;
}