//
// Created by lucka on 11/4/2022.
//

#include "Item.h"

Item::Item(ItemType type, ItemQuality quality, int agility, int defence, int strength, int health, std::array<int,2>pos){
    m_id=m_count;
    m_count++;
    m_type = type;
    m_quality = quality;
    m_agility = agility;
    m_defence = defence;
    m_strength = strength;
    m_health = health;
    m_pos = pos;
    m_equipped = false;
}

Item::Item(int goldValue){
    m_id++;
    m_type = ItemType::Gold;
    m_health = goldValue;
    m_quality = ItemQuality::Legendary;
    m_agility = 0;
    m_defence = 0;
    m_strength = 0;
}

int Item::getId(){
    return m_id;
}

ItemType Item::getType(){
    return m_type;
}

ItemQuality Item::getQuality(){
    return m_quality;
}

int Item::getAgility(){
    return m_agility;
}

int Item::getDefence(){
    return m_defence;
}

int Item::getStrength(){
    return m_strength;
}

int Item::getHealth(){
    return m_health;
}

std::array<int,2> Item::getPos(){
    return m_pos;
}

void Item::setPos(std::array<int,2> pos){
    m_pos = pos;
}

void Item::setEquip(bool equip){
    m_equipped = equip;
}

bool Item::isEquipped(){
    return m_equipped;
}
void Item::setHealth(int health){
    m_health=health;
}
void Item::setStrength(int strength){
    m_strength=strength;
}
void Item::setAgility(int agility){
    m_agility=agility;
}
void Item::setDefence(int defence){
    m_defence = defence;
}
void Item::setQuality(ItemQuality quality){
    m_quality=quality;
}