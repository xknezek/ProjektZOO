//
// Created by lucka on 11/4/2022.
//

#include "Patron.h"

Patron::Patron() {
}

bool Patron::craftByQuality(int index, Player* player) {
    m_player = player;
    if (m_player->getInventory().at(index)->getType() == ItemType::Potion){
        return false;
    }
    if(quantityCheck(index) && m_player->getInventory().at(0)->getHealth() > 100){
        int newAgility, newStrength, newDefence;
        newAgility = ((m_player->getInventory().at(index)->getAgility() + first->getAgility() + second->getAgility()) / 3) + rand()%5+2;
        newDefence = ((m_player->getInventory().at(index)->getDefence() + first->getDefence() + second->getDefence()) / 3) + rand()%5+2;
        newStrength = ((m_player->getInventory().at(index)->getStrength() + first->getStrength() + second->getStrength())/ 3) + rand()%5+2;
        m_player->getInventory().at(index)->setAgility(newAgility);
        m_player->getInventory().at(index)->setStrength(newStrength);
        m_player->getInventory().at(index)->setDefence(newDefence);
        switch (m_player->getInventory().at(index)->getQuality()) {
            case ItemQuality::Common:
                m_player->getInventory().at(index)->setQuality(ItemQuality::Uncommon);
                break;
            case ItemQuality::Uncommon:
                m_player->getInventory().at(index)->setQuality(ItemQuality::Rare);
                break;
            case ItemQuality::Rare:
                m_player->getInventory().at(index)->setQuality(ItemQuality::Epic);
                break;
            case ItemQuality::Epic:
                m_player->getInventory().at(index)->setQuality(ItemQuality::Legendary);
                break;
            default:
                std::cout<<"Max quality reached!"<<std::endl;
                break;
        }
        m_player->getInventory().at(0)->setHealth(m_player->getInventory().at(0)->getHealth() - 100);
        clearUsed();
        return true;
    }
    else return false;
}
bool Patron::quantityCheck(int index) {
    int check = 0;
    if(!m_player->getInventory().at(index))
    {
        return false;
    }
    for (int i = 0; i < m_player->getInventory().size(); i++) {
        if(!m_player->getInventory().at(i))
        {
            continue;
        }
        if (m_player->getInventory().at(i) != m_player->getInventory().at(index) &&
                m_player->getInventory().at(i)->getType() == m_player->getInventory().at(index)->getType() &&
                m_player->getInventory().at(i)->getQuality() == m_player->getInventory().at(index)->getQuality()) {
            check++;
        }
        if (check == 1) {
            first = m_player->getInventory().at(i);
        } else if (check == 2) {
            second = m_player->getInventory().at(i);
            return true;
        }
    }
    return false;
}
void Patron::clearUsed(){
    if(first){
        delete m_player->dropItem(first);
    }
    if(second){
        delete m_player->dropItem(second);
    }
}


