//
// Created by filip on 25.12.2022.
//

#ifndef PROJECTX_COLORS_H
#define PROJECTX_COLORS_H

enum class Colors{
    Black = 0,
    DarkBlue = 1,
    DarkGreen = 2,
    DarkCyan = 3,
    DarkRed = 4,
    DarkPurple = 5,
    DarkYellow = 6,
    DarkWhite = 7,
    LightBlack = 0 + 8,
    LightBlue = 1 + 8,
    LightGreen = 2 + 8,
    LightCyan = 3 + 8,
    LightRed = 4 + 8,
    LightPurple = 5 + 8,
    LightYellow = 6 + 8,
    White = 7 + 8,
};

#endif //PROJECTX_COLORS_H
