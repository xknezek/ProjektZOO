//
// Created by filip on 09.11.2022.
//

#include "Room.h"

Room::Room(Room* left, Room* right, Room* up, Room* down, std::vector<std::vector<std::string>> roomContent, std::array<int, 2> size, std::vector<Enemy*> enemies, std::vector<Item*> items, Player* player){
    m_left = left;
    m_right = right;
    m_up = up;
    m_down = down;
    m_roomContent = roomContent;
    m_size = size;
    m_enemies = enemies;
    m_items = items;
    m_player = player;
    if(!m_left){
        for (int i = 0; i < m_roomContent.size(); i++) {
            m_roomContent.at(0).at(i)="#";
        }
    }
    if(!m_right){
        for (int i = 0; i < m_roomContent.size(); i++) {
            m_roomContent.at(i).at(m_roomContent.size()-1)="#";
        }
    }
    if(!m_up){
        for (int i = 0; i < m_roomContent.size(); i++) {
            m_roomContent.at(i).at(0)="#";
        }
    }
    if(!m_down){
        for (int i = 0; i < m_roomContent.size(); i++) {
            m_roomContent.at(m_roomContent.size()-1).at(i)="#";
        }
    }
}

Room::Room(std::vector<std::vector<std::string>> roomContent, std::array<int, 2> size, std::vector<Enemy*> enemies, std::vector<Item*> items, Player* player){
    m_left = nullptr;
    m_right = nullptr;
    m_up = nullptr;
    m_down = nullptr;
    m_roomContent = roomContent;
    m_size = size;
    m_enemies = enemies;
    m_items = items;
    m_player = player;
    for (int i = 0; i < m_roomContent.size(); i++) {
        m_roomContent.at(0).at(i)="#";
    }//left

    for (int i = 0; i < m_roomContent.size(); i++) {
        m_roomContent.at(i).at(m_roomContent.size()-1)="#";
    }//right

    for (int i = 0; i < m_roomContent.size(); i++) {
        m_roomContent.at(i).at(0)="#";
    }//up

    for (int i = 0; i < m_roomContent.size(); i++) {
        m_roomContent.at(m_roomContent.size()-1).at(i)="#";
    }//down
}

Room* Room::getLeft() {
    return m_left;
}

Room* Room::getRight() {
    return m_right;
}

Room* Room::getUp() {
    return m_up;
}

Room* Room::getDown() {
    return m_down;
}

void Room::setLeft(Room *room) {
    m_left = room;
    if(m_left){
        if(m_roomContent.size()<10){
            m_roomContent.at(4).at(0)=" ";
        } else {
            m_roomContent.at(7).at(0)=" ";
            m_roomContent.at(8).at(0)=" ";
        }
    }
}

void Room::setRight(Room *room) {
    m_right = room;
    if(m_right){
        if(m_roomContent.size()<10){
            m_roomContent.at(4).at(8)=" ";
        } else {
            m_roomContent.at(7).at(15)=" ";
            m_roomContent.at(8).at(15)=" ";
        }
    }
}

void Room::setUp(Room *room) {
    m_up = room;
    if(m_up){
        if(m_roomContent.size()<10){
            m_roomContent.at(0).at(4)=" ";
        } else {
            m_roomContent.at(0).at(7)=" ";
            m_roomContent.at(0).at(8)=" ";
        }
    }
}

void Room::setDown(Room *room) {
    m_down = room;
    if(m_down){
        if(m_roomContent.size()<10){
            m_roomContent.at(8).at(4)=" ";
        } else {
            m_roomContent.at(15).at(7)=" ";
            m_roomContent.at(15).at(8)=" ";
        }
    }
}

std::string Room::getTile(std::array<int, 2> pos){
    return m_roomContent.at(pos[0]).at(pos[1]);
}

void Room::setTile(std::array<int, 2> pos, std::string tile){
    m_roomContent.at(pos[0]).at(pos[1]) = tile;
}

std::array<int, 2> Room::getSize() {
    return m_size;
}

std::vector<Enemy*> Room::getEnemies() {
    std::vector<Enemy*> enemies;
    for (Enemy* enemy: m_enemies) {
        if (enemy->getHealth() > 0) {
            enemies.push_back(enemy);
        }
    }
    return enemies;
}

std::vector<Item*> Room::getItems() {
    return m_items;
}

void Room::setPlayer(Player *player) {
    m_player = player;
}

Player* Room::getPlayer() {
    return m_player;
}

bool Room::checkPos(std::array<int, 2> pos){
    if (pos[0] >= m_roomContent.size() || pos[1] >= m_roomContent.at(0).size() || pos[0] < 0 || pos[1] < 0){ //continue if upcoming is outside of map
        return false;
    }
    return true;
}

//dostane item dropnutý z inventáře entity a dropne ho na nejbližší volné políčko na zemi (když na zemi není místo -> smaže item)
void Room::dropItem(Item *item) {
    if(!item)return;
    std::array<int, 2> pos;
    pos = checkEmptyNeighbourPosition(1, m_player->getPosition());
    if (!(pos.at(0) < 0 || pos.at(1) < 0)) {
        item->setPos(pos);
        m_items.push_back(item);
        setTile(pos,"?");
        return;
    }
    delete item;
}

std::array<int, 2> Room::checkEmptyNeighbourPosition(int circle, std::array<int, 2> pos){
    if(circle > m_roomContent.size()) {
        return {-1,-1};
    }
    for(int i = -circle; i < circle + 1; i++){
        for(int j = -circle; j < circle + 1; j++){
            std::array<int, 2> actualPos = {pos.at(0) + i, pos.at(1) + j};
            if(i == circle && j == circle){
                return checkEmptyNeighbourPosition(++circle, pos);
            }
            if(!checkPos(actualPos)){
                continue;
            }
            if(getTile(actualPos) == " " && !(i == 0 && j == 0)){
                return actualPos;
            }
        }
    }
    return {-1,-1};
}

Item* Room::pickItem(Item* item){
    int itemIndex;
    for (int i = 0; i < m_items.size(); i++) {

        if(m_items.at(i)->getId()==item->getId()){
            itemIndex=i;
            break;
        }
    }
    m_items.erase(m_items.begin()+itemIndex);
    return item;
}

void Room::setEnemy(Enemy *enemy, int index) {
    m_enemies.at(index)=enemy;
}

bool Room::checkCompleted(){
    if (getEnemies().empty()){
        return true;
    }
    return false;
}

Room::~Room() {
    for (Item* item: m_items) {
        delete item;
    }
    for (Enemy* enemy: m_enemies) {
        delete enemy;
    }
    delete m_player;
}

