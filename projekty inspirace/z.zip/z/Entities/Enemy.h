//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_ENEMY_H
#define PROJECTX_ENEMY_H

#include "Entity.h"



/**
 * Enemy class for loot.
 */
class Enemy:public Entity{
private:
    static int m_count;
    int m_id;
public:
    Enemy(int agility,int defence,int health,int strength,int maxHealth,std::array<int,2>Position);

    /**
     * Void function to drop loot for player after a fight.
     */
    void dropInventory();

};


#endif //PROJECTX_ENEMY_H
