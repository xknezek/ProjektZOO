//
// Created by lucka on 11/4/2022.
// Edited by Michal on 11/11/2022 *****Patch 0.2.5
//

#include "Combat.h"

Combat::Combat(Player *player, Enemy *enemy, bool playerTurn) {
    m_enemy = enemy;
    m_player = player;
    m_playerTurn = playerTurn;
    light = new Light(player, enemy);
    heavy = new Heavy(player, enemy);
}

//metoda pro logiku combatu
void Combat::round(AttackType attType, bool playerTurn) {
    if (playerTurn && attType == AttackType::Light) {
        light->calcPlayerDmg();
    }
    if (playerTurn && attType == AttackType::Heavy) {
        heavy->calcPlayerDmg();
    }
    if (!playerTurn && attType == AttackType::Light) {
        light->calcEnemyDmg();
    }
    if (!playerTurn && attType == AttackType::Heavy) {
        heavy->calcEnemyDmg();
    }
    //m_playerTurn = !m_playerTurn;
    //TODO LOGIC FOR DEATH CERTIFICATE

}

//metoda pro logiku uteku
bool Combat::flee() {
    if (rand() % 100 <= std::max(m_player->getTotalAgility() * std::max(m_player->getLuck() / 20, float(1)), float(10))) {
        return true;
    } else {
        m_playerTurn = false;
        m_player->setHealth(int(m_player->getHealth() - std::max((m_enemy->getTotalStrength() / 2) - m_player->getTotalDefence(), 1)));
        return false;
    }
}