//
// Created by lucka on 11/4/2022.
//

#ifndef PROJECTX_LOAD_H
#define PROJECTX_LOAD_H


class Load {

};


#endif //PROJECTX_LOAD_H
