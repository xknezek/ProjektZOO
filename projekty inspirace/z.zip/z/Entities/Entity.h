//
// Created by filip on 04.11.2022.
// Edited by Michal Kadlec on 09.11.2022
//

#ifndef PROJECTX_ENTITY_H
#define PROJECTX_ENTITY_H

#include <iostream>     // Podstatný definice
#include <vector>
#include <array>
#include "../Inventory/Item.h"
#include "../Inventory/Inventory.h"

/**
 * Entity class for player's and enemy's shared properties.
 */
class Entity {
protected:
    int m_agility,
        m_defence,
        m_health,
        m_strength,
        m_maxHealth;
        std::array<int,2> m_position;
        Inventory* m_inventory = new Inventory();
public:
    /**
     * Constructor for entity.
     * @param agility
     * @param defence
     * @param health
     * @param strength
     * @param maxHealth
     * @param Position
     */
    Entity(int agility,int defence,int health,int strength,int maxHealth,std::array<int,2>Position);

    /**
     *Int function to get agility level.
     * @return Returns agility level.
     */
    int getAgility();

    /**
     *Int function to get defence level.
     * @return Returns defence level.
     */
    int getDefence();

    /**
     *Int function to get strength level.
     * @return Returns strength level.
     */
    int getStrength();

    /**
     *Int function to get maximum value of health.
     * @return Returns maximum value of health.
     */
    int getMaxHealth();

    /**
     *Int function to get health level.
     * @return Returns value of health.
     */
    int getHealth();

    /**
     *Void function to set health value.
     * @param Health Value based on default health level, can be decreased in a fight, can be increased by healing.
     */
    void setHealth(int Health);

    /**
     *Function to get position from array.
     * @return Returns position of player or enemy.
     */
    std::array<int,2> getPosition();

    /**
     *Void function to set the position of player or enemy.
     * @param Position Value based on player's or enemy's position.
     */
    void setPosition(std::array<int,2>Position);

    /**
     *Function to get contents of player's inventory.
     * @return Returns contents of player's inventory.
     */
    std::vector<Item* >getInventory();

    /**
     *Void function to get player's total agility.
     * @param Returns player's total agility.
     */
    int getTotalAgility();

    /**
     *Int function to get player's total defence.
     * @return Returns player's total defence.
     */
    int getTotalDefence();

    /**
     *Int function to get player's total strength.
     * @return Returns player's total strength.
     */
    int getTotalStrength();

    /**
     *Int function to get player's total health.
     * @return Returns player's total health.
     */
    int getTotalMaxHealth();

    /**
     * Bool function to add picked up item to player's inventory.
     * @param item Reference to item.
     * @return Returns picked up item to player's inventory.
     */
    bool addItem(Item* item);
};


#endif //PROJECTX_ENTITY_H
