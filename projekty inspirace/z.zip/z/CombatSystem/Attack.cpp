//
// Created by czem1 on 07.12.2022.
//

#include "Attack.h"

Attack::Attack(Player* player, Enemy* enemy, float damageAffinity, float attackAffinity){
    m_player = player;
    m_enemy = enemy;
    m_damageAffinity = damageAffinity;
    m_attackAffinity = attackAffinity;
}
